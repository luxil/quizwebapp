/* Hello, World! program in node.js */
console.log("Hello, World!")